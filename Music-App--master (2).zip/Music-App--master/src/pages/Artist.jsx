import React from "react"
import { Artists, LayoutSidebar } from "../router"

export const Artist = () => {
  return (
    <>
      <LayoutSidebar>
        <Artists />
      </LayoutSidebar>
    </>
  )
}
