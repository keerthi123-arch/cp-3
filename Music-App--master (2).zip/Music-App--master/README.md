Project Demo : https://chimerical-puffpuff-68664f.netlify.app/

Project Video : https://www.youtube.com/watch?v=VHIa85dW9mg&ab_channel=GorkCoder 

![tailwind css](https://user-images.githubusercontent.com/67497228/209465700-cc30e70a-345e-4ad8-a796-44f46b539a87.jpg)
